Instruction:
In order to reproduce our experiment results,follow the instructions ad following:
1. Use the python version 3.6+
2. Download the train data set and test data set
3. cd code\ and run run.py


The description of code:

1. Get data
a. proj1_helpers.py: Load and read the data.csv and create the submission.csv

2. Data preparation
a. preprocessing.py: Preprocess the train/test data
b. degree_selection.py: Select the best degree for feature scaling

3. Algorithms implementation
a. implementions.py: Six basic machine learning algorithms
b. implementations.helper.py: Define corresponding functions in implementaytions.py
c. parameter_choosing.py: Choose the best model pamameters
d. parameter_choosing_helper.py: Define corresponding functions in parameter_choosing.py
e. modle_compare.py: Compare the performance of models with different parameters
f. test_algorithms,py: Test the performance of six models

4. Cross validation
a. cross_validation.py: Implement k-fold cross validation
b. test_cross_validation.py: The experiment about how the performance change with k

5. Main function
a. run.py: Implement six machine learning algorithms, choose the best one and create the submission.

