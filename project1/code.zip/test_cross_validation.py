import sys
from preprocessing import *
from implementations import *
# from implementations_helpers import*
from cross_validation import *
from proj1_helpers import *
import matplotlib.pyplot as plt

'''
This program is to test how the prediction accuracy and its variance change according to the group number k.

In the different k-fold algorithms, we output the accuracy and variance
'''
if __name__ == '__main__':
    # load data
    y_train, x_train, id_train = load_csv_data(
        "/Users/maxiaoqi/Desktop/ML_course-master-3/projects/project1/data/train.csv")
    y_test, x_test, id_test = load_csv_data(
        "/Users/maxiaoqi/Desktop/ML_course-master-3/projects/project1/data/test.csv")
    jet_index_train = data_mass_index(x_train)
    jet_index_test = data_mass_index(x_test)
    x_train = data_processing(x_train)
    x_test = data_processing(x_test)

    # set different group number k
    k=[2,5,10,20,30,40,50,60,70,80,90]

    # initialize
    degrees = [4, 6, 6, 7, 5, 5, 2, 1]
    variances = []
    y_pred_test = np.zeros(len(y_test))

    # iterate through three
    total_len = 0
    accuracy = np.zeros(8)
    variance = np.zeros(8)
    for j in range(len(k)):
        for i in range(len(jet_index_train)):
            degree = degrees[i]
            train_index = jet_index_train[i]
            test_index = jet_index_test[i]

            # get train/test data for each grouptrain_sets = get_sets(data_train)
            x_tr, y_tr = x_train[train_index], y_train[train_index]
            x_te, y_te = x_test[test_index], y_test[test_index]

            # get predict result
            x_tr = eliminate_invalid_columns(x_tr, i)
            x_te = eliminate_invalid_columns(x_te, i)

            x_tr = standardize(x_tr)
            x_te = standardize(x_te)

            tx_train = build_poly(x_tr, degree)
            tx_test = build_poly(x_te, degree)
            loss, w, accuracy[i], variance[i] = cross_validation(tx_train, y_tr, k[j],0.00001)
            y_pred_te = predict_labels(w, tx_test)
            total_len += len(y_pred_te)
            y_pred_test[test_index] = y_pred_te

        # calculate results
        # accuracy
        total_accuracy = 0
        total_num = 0
        for i in range(len(jet_index_train)):
            total_accuracy = total_accuracy + accuracy[i] * len(jet_index_train[i])
            total_num = total_num + len(jet_index_train[i])
        total_accuracy = total_accuracy / total_num
        
        #variance
        total_variance =0
        total_num2=0
        for i in range(len(jet_index_train)):
            total_variance = total_variance + variance[i] * len(jet_index_train[i])
            total_num2 = total_num2 + len(jet_index_train[i])
        total_variance = total_variance / total_num2

        # display results
        print(accuracy)
        print(total_accuracy)
        print(variance)
        print(total_variance)

        print("Submission results can be found in the ./data subdirectory")
