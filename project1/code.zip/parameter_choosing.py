# -*- coding: utf-8 -*-
"""
define parameter selection function for each learning algorithms,
the parameters are gamma, max_iters, lambda
(except least_squares, since it so not have parameter need to be choose)
"""
import random
from parameter_choosing_helper import *

y_train, x_train, id_train = load_csv_data("train.csv")

jet_index_train = data_mass_index(x_train)

x_train = data_processing(x_train)
    
lambda_ = 1
#initial_w = np.zeros([d,])
max_iters = 5000
gamma = 0.0001

epsilon = 0.0001
max_iters_increase = 1000
gamma_decrease = 0.00001 
lambda_increase = 0.1   

idx = jet_index_train[0]
x0, y0 = x_train[idx], y_train[idx]
tx0 = build_poly(x0, 1)
d = tx0.shape[1]
y0_test,tx0_test,y0_train,tx0_train = split_dataset(y0,tx0,ratio = 0.25)

initial_w = np.zeros([d,])

function_types = ['least_squares_GD','least_squares_GD',
                  'least_squares','ridge_regression','logistic_regression','reg_logistic_regression']

best_parameters = []

for function_type in function_types:
    lambda_ = 1
    #initial_w = np.zeros([d,])
    max_iters = 6000
    gamma = 0.0001
    best_parameter = [0,0,0]
    acurracy0 = 0
    acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type)
    for i in range(10):
        acurracy0 = acurracy
        max_iters += max_iters_increase
        acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type)
        if abs(acurracy-acurracy0) < epsilon:
            break
        
    best_parameter[0] = max_iters
        
    acurracy0 = 0
    acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type)   
    for i in range(10):
        acurracy0 = acurracy
        gamma -= gamma_decrease
        acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type)
        if abs(acurracy-acurracy0) < epsilon:
            break
    best_parameter[1] = gamma
        
    if (function_type is 'least_squares') or (function_type is 'ridge_regression') :
        acurracy0 = 0
        acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type)
        for i in range(10) :
            acurracy0 = acurracy
            lambda_ += lambda_increase
            acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, 
                     lambda_ ,initial_w, max_iters, gamma, function_type)
            if abs(acurracy-acurracy0) < epsilon:
                break
        best_parameter[2] = lambda_
        
    best_parameter.append(best_parameter)
    print(function_type+':max_iters ='+str(max_iters)+',  gamma ='+str(gamma)+',  lambda = '+str(lambda_)+'\n')