# -*- coding: utf-8 -*-
"""
the script that gives the final rsults
"""
import sys
#sys.path.append("/data_wrangling")
from preprocessing import *
from implementations import *
#from implementations_helpers import*
from cross_validation import *
from proj1_helpers import *
import matplotlib.pyplot as plt

#please change the path to your own path
y_train, x_train, id_train = load_csv_data("train.csv")
y_test, x_test, id_test = load_csv_data("test.csv")

jet_index_train = data_mass_index(x_train)
jet_index_test = data_mass_index(x_test)
x_train = data_processing(x_train)
x_test = data_processing(x_test)

 

degrees = [4, 6, 6, 7, 5, 5, 2, 1]
lambda_=0.00001

variances = []

y_pred_test = np.zeros(len(y_test))
# iterate through three 
total_len = 0
accuracy=np.zeros(8);
for i in range(len(jet_index_train)):
    degree = degrees[i]
    train_index = jet_index_train[i]
    test_index = jet_index_test[i]
    #print(test_index)
    # get train/test data for each grouptrain_sets = get_sets(data_train)
    x_tr, y_tr = x_train[train_index], y_train[train_index]
    x_te, y_te = x_test[test_index], y_test[test_index]
    # data preprocessy_pred_all = np.array([])
    #get predict resul
    #data_processing(x_train)
    #data_processing(x_test)
    x_tr = eliminate_invalid_columns(x_tr,i)
    x_te = eliminate_invalid_columns(x_te,i)
    
    x_tr = standardize(x_tr)
    x_te = standardize(x_te)
    
    tx_train = build_poly(x_tr, degree)
    tx_test = build_poly(x_te, degree)
    initial_w = np.zeros(tx_train.shape[1])
    #loss,w=ridge_regression(y_tr, tx_train,lambda_)
    loss,w,accuracy[i],variance=cross_validation(tx_train,y_tr,5, lambda_ ,initial_w , max_iters=6000, gamma=0.0001,function_type = 'ridge_regression')
    #loss,w=least_squares(y_tr, tx_train)
    #acuracy_best = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, lambda_ ,initial_w, max_iters, gamma, function_type='least_squares_SGD')
    
    y_pred_te = predict_labels(w, tx_test)
    total_len += len(y_pred_te)
    #print(np.where(y_pred_te == 0))
    y_pred_test[test_index] = y_pred_te
    #variances.append(variance)

result=0
total_num=0
for i in range(len(jet_index_train)):
    result=result+accuracy[i]*len(jet_index_train[i])
    total_num=total_num+len(jet_index_train[i])
result=result/total_num
    
print(accuracy)
print(result)



create_csv_submission(id_test, y_pred_test, "sample-submission.csv")




print("Submission results can be found in the ./data subdirectory")