import csv
import numpy as np
import matplotlib.pyplot as plt
from implementations_helpers import *
from implementations import *
from mpl_toolkits.mplot3d import Axes3D
from proj1_helpers import *


def standardize(x):
    '''normalize each colum'''
    x = cleaning_999_mean(x)
    epsilon = 1e-10
    mean = np.mean(x, axis=0)
    std = np.std(x, axis=0)
    
    indx = np.where(std<epsilon)
    std[indx] = epsilon
    x = (x-mean)/std
    return x


def cleaning_999_mean(x):
    '''for value in each column,change the invalid valid value'-999' into the mean of each column'''
    for i in range(x.shape[1]):
        temp_col=x[:,i]
        arr=np.where(temp_col==-999)
        new_col=np.delete(temp_col,arr)
        new_mean=np.mean(new_col)
        temp_col[temp_col==-999]=new_mean

    return x


def process_999_columns(x):
    '''invalid check: for each featute(column),delete it if all values in this column are equal to -999'''
    invalid_col = []
    for i in range(x.shape[1]):
        temp_col = x[:, i]
        invalid=(temp_col==-999)
        if (invalid.all()==True):
            invalid_col.append(i)
    x = np.delete(x, invalid_col, axis=1)
    return x


def process_999_rows(x):
    '''invalid check: for each row, delete it if all values in this row are equall to -999'''
    invalid_col=[]
    for i in range(x.shape[0]):
        temp_col = x[i,:]
        invalid =(temp_col==-999)
        if(invalid.all()==True):
            invalid_col.append(i)
    x = np.delete(x, invalid_col, axis=0)
    return x


def data_processing(x):

    x = process_999_columns(x)
    x = process_999_rows(x)

    return x


def PRI_jet_index(x):
    '''according to the feature"PRI_jet_index,its value is 1/2/3/4,so we split the data into 4 categories.
           then get the index of different sample'''
    index_0 = np.where(x[:, 22] == 0)[0]
    index_1 = np.where(x[:, 22] == 1)[0]
    index_2 = np.where(x[:, 22] == 2)[0]
    index_3 = np.where(x[:, 22] == 3)[0]

    return[index_0,index_1,index_2,index_3]


def data_mass_index(x):
    '''according to the data_mass, we split the four type of sets into 8 categories'''
    index_0, index_1, index_2, index_3=PRI_jet_index(x)
    x_0 = x[index_0]
    x_1 = x[index_1]
    x_2 = x[index_2]
    x_3 = x[index_3]
    index_a0=index_0[np.where(x_0[:,0]>0)[0]]
    index_a1=index_1[np.where(x_1[:,0]>0)[0]]
    index_a2=index_2[np.where(x_2[:,0]>0)[0]]
    index_a3=index_3[np.where(x_3[:,0]>0)[0]]
    index_b0=index_0[np.where(x_0[:,0]<0)[0]]
    index_b1=index_1[np.where(x_1[:,0]<0)[0]]
    index_b2=index_2[np.where(x_2[:,0]<0)[0]]
    index_b3=index_3[np.where(x_3[:,0]<0)[0]]
    return [index_a0,index_a1,index_a2,index_a3,index_b0,index_b1,index_b2,index_b3]


def eliminate_invalid_columns(x,i):
    '''delete the feature(a)unchanged feature (b)invalid feature（c)correlated feature'''
    [index_a0, index_a1, index_a2, index_a3, index_b0, index_b1, index_b2, index_b3]=data_mass_index(x)
    if i==0:
        return np.delete(x[index_a0], [3,4,5,6,12,22,23,24,25,26,27,28,29], axis=1)
    if i==1:
        return np.delete(x[index_a1], [4,5,6,12,22,26,27,28,29], axis=1)
    if i==2:
        return np.delete(x[index_a2], [4,22,29], axis=1)
    if i==3:
        return np.delete(x[index_a3], [4,22], axis=1)
    if i==4:
        return np.delete(x[index_b0], [0,3,4,5,6,12,22,23,24,25,26,27,28,29], axis=1)
    if i==5:
        return np.delete(x[index_b1], [0,4,5,6,12,22,26,27,28,29], axis=1)
    if i==6:
        return np.delete(x[index_b2], [0,4,22,29], axis=1)
    if i==7:
        return np.delete(x[index_b3], [0,4,22], axis=1)
    else:
        return 0


def build_poly(x, degree):
    '''feature scaling: for different groups
    input:data,degree
    output:new data'''

    base = np.ones((x.shape[0], 1))
    for power in range(1, degree+1):
        newCol = np.power(x, power)
        base = np.concatenate((base, newCol), axis=1)

    return base




















