# -*- coding: utf-8 -*-
"""
Define some functions used in implementations.py
"""
import numpy as np


def compute_loss_LS(y, tx, w, loss_type = 'MSE'):
    """
    compute the loss function of linear model,
    it can both compute mean square error and mean absolute error,
    the default is mean square error.
    input: 
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        w: the paramater of each feature
        loss_type: 'MSE' or 'MAE'
    output:
        The value of coorresponding loss function L(w), a positive number 
    """
    e = y - tx.dot(w)
    return 1/2*np.mean(e**2)


def compute_gradient_LS(y, tx, w, loss_type = 'MSE'):
    """
    compute the gradient of linear model,
    it can both compute mean square error and mean absolute error,
    the default is mean square error.
    input: 
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        w: the paramater of each feature
        loss_type: 'MSE' or 'MAE'
    output:
        The gradient of coorresponding loss function L(w), d*1 normalized vector
    """
    e = y - tx.dot(w)
    
    gradient = -(tx.T).dot(e)
    gradient_normed = gradient/np.linalg.norm(gradient)
    return gradient_normed

        
def batch_iter(y, tx, batch_size, num_batches=1, shuffle=True):
    """
    Generate a minibatch iterator for a dataset.
    Takes as input two iterables (here the output desired values 'y' and the input data 'tx')
    Outputs an iterator which gives mini-batches of `batch_size` matching elements from `y` and `tx`.
    Data can be randomly shuffled to avoid ordering in the original data messing with the randomness of the minibatches.
    Example of use :
    for minibatch_y, minibatch_tx in batch_iter(y, tx, 32):
        <DO-SOMETHING>
    """
    data_size = len(y)

    if shuffle:
        shuffle_indices = np.random.permutation(np.arange(data_size))
        shuffled_y = y[shuffle_indices]
        shuffled_tx = tx[shuffle_indices]
    else:
        shuffled_y = y
        shuffled_tx = tx
    for batch_num in range(num_batches):
        start_index = batch_num * batch_size
        end_index = min((batch_num + 1) * batch_size, data_size)
        if start_index != end_index:
            yield shuffled_y[start_index:end_index], shuffled_tx[start_index:end_index]
            
            
def sigmoid(t):
    """
    calculate the sigmoid function
    input:
        a matrix
    output:
        a matrix of the same size, each elements of the matrix is taken the sigmoid
        
    """
    return 1/(1+np.exp(-t))


def compute_loss_Logistic(y,tx,w):
    """
    compute the loss of logistic loss function
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        w: the paramater of each feature
    output:
        The value of coorresponding loss function L(w), a positive number 
        
    """
    epsilon = 10**(-10)
    tx_temp = sigmoid(tx.dot(w))
    zero_idx = np.where(abs(tx_temp-0)<epsilon)
    one_idx = np.where(abs(tx_temp-1)<epsilon)
    tx_temp[zero_idx] = epsilon
    tx_temp[one_idx] = 1-epsilon 
    return -(y.T.dot(np.log(tx_temp))+(1-y).T.dot(np.log(1-tx_temp)))

def compute_gradient_Logistic(y,tx,w):
    """
    Compute the gradient of logistic loss function
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        w: the paramater of each feature
    output:
        The gradient of coorresponding loss function L(w), d*1 normalized vector 
    """
    gradient = tx.T.dot(sigmoid(tx.dot(w))-y)
    gradient_normed = gradient/np.linalg.norm(gradient)
    return gradient_normed

def compute_gradient_reg_Logistic(y,tx,w,lambda_):
    """
    Compute the gradient of regularized logistic loss function
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        w: the paramater of each feature
        lambda_: the parameter of regularizer
    output:
        The gradient of coorresponding loss function L(w), d*1 normalized vector 
    """
    gradient = tx.T.dot(sigmoid(tx.dot(w))-y) + 2*lambda_*w
    gradient_normed = gradient/np.linalg.norm(gradient)
    return gradient_normed