# -*- coding: utf-8 -*-
'''
This script test the accuracy for each learning algorithms

'''
import sys
#sys.path.append("/data_wrangling")
from preprocessing import *
from implementations import *
#from implementations_helpers import*
from cross_validation import *
from proj1_helpers import *
import matplotlib.pyplot as plt
function_types = ['least_squares','ridge_regression','least_squares_GD',
                  'logistic_regression','reg_logistic_regression', 'least_squares_SGD']

#function_types = ['least_squares_GD','logistic_regression','reg_logistic_regression']
accuracies_function = []

#load data,partition into groups and data preprocessing
y_train, x_train, id_train = load_csv_data("train.csv")
y_test, x_test, id_test = load_csv_data("test.csv")
jet_index_train = data_mass_index(x_train)
jet_index_test = data_mass_index(x_test)
x_train = data_processing(x_train)
x_test = data_processing(x_test)

# learning parameters
degrees = [4, 6, 6, 7, 5, 5, 2, 1]
lambda_=0.00001
max_iters = 8000
gamma = 0.0001 
variances = []

y_pred_test = np.zeros(len(y_test))


# iterate through three 
total_len = 0
accuracies=np.zeros(8);

d = {'least_squares':[],'ridge_regression':[],'least_squares_GD':[],'least_squares_SGD':[],
                  'logistic_regression':[],'reg_logistic_regression':[]}
#learning for  each group
for i in range(len(jet_index_train)):
    degree = degrees[i]
    train_index = jet_index_train[i]
    test_index = jet_index_test[i]

    x_tr, y_tr = x_train[train_index], y_train[train_index]
    x_te, y_te = x_test[test_index], y_test[test_index]
    
    # eliminate invalid columns
    x_tr = eliminate_invalid_columns(x_tr,i)
    x_te = eliminate_invalid_columns(x_te,i)
    
    x_tr = standardize(x_tr)
    x_te = standardize(x_te)
    
    tx_train = build_poly(x_tr, degree)
    tx_test = build_poly(x_te, degree)
    
    
    # use cross validation to test the accuracy of each learning algorithms
    initial_w  = np.zeros(tx_train.shape[1])
    for function_type in function_types:
        loss,w,accuracy,variance=cross_validation(tx_train,y_tr,5,lambda_ , initial_w , max_iters, gamma,function_type )
        d[function_type].append(accuracy)
        print(function_type+'  ,group:'+str(i))
    y_pred_te = predict_labels(w, tx_test)
    total_len += len(y_pred_te)

    y_pred_test[test_index] = y_pred_te
    variances.append(variance)
   
for function_type in function_types:
    result=0
    total_num=0
    accuracies = d[function_type]
    for i in range(len(jet_index_train)):
        result=result+accuracies[i]*len(jet_index_train[i])
        total_num=total_num+len(jet_index_train[i])
    result=result/total_num
    accuracies_function.append(result)
    print(function_type+'accuracy is: '+str(result)+'\n')
