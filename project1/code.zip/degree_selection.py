# -*- coding: utf-8 -*-
"""
Select the degree for each group
"""
import sys
#sys.path.append("/data_wrangling")
from preprocessing import *
from implementations import *
#from implementations_helpers import*
from proj1_helpers import *
import matplotlib.pyplot as plt
import random
from parameter_choosing_helper import *

y_train, x_train, id_train = load_csv_data("train.csv")

jet_index_train = data_mass_index(x_train)

x_train = data_processing(x_train)  

#x_train = standardize(x_train)
lambda_ = 0.0000001
#initial_w = np.zeros([d,])
max_iters = 5000
gamma = 0.0002

epsilon = 0.001
max_iters_increase = 1000
gamma_decrease = 0.00001 
lambda_increase = 0.00001   

degrees = [1,1,1,1,1,1,1,1]
accurracy_each = [0,0,0,0,0,0,0,0]

for i in range(len(jet_index_train)):
    degree = degrees[i]
    idx = jet_index_train[i]
    x0, y0 = x_train[idx], y_train[idx]
   
    x0 = eliminate_invalid_columns(x0,i)
    x0 = standardize(x0)
    
    d = x0.shape[1]
    
    initial_w = np.zeros([d,])
    
    #for each degree, test it and find the optimal degree for each group
    acurracies = []
    degree_range = [1+x for x in range(14)]
    for degree in degree_range:
        tx0 = build_poly(x0, degree)
        d = tx0.shape[1]
        #y0_test,tx0_test,y0_train,tx0_train = split_dataset(y0,tx0,ratio = 0.3)
        #acurracy = get_acurracy(y0_test, tx0_test, y0_train, tx0_train, lambda_ ,initial_w, max_iters, gamma, function_type = 'ridge_regression')
        loss,w,accuracy,variance = cross_validation(tx0 , y0, 5, lambda_ , initial_w =1, max_iters=1, gamma=1,function_type = 'ridge_regression')
        
        acurracies.append(accuracy)
    print(acurracies) 
    best_index = acurracies.index(max(acurracies))
    accurracy_each[i] = max(acurracies)
    degrees[i] = degree_range[best_index]