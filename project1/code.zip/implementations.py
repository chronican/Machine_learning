# -*- coding: utf-8 -*-
"""
Implementations of learning algorithms
"""

import numpy as np
from implementations_helpers import *



def least_squares_GD(y, tx, initial_w,max_iters, gamma):
    '''
    Linear regression using gradient descent
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        initial_w: the initial paramater of each feature, d*1 vector
        max_iters: the maximum iterations of this algorithm, an integer
        gamma: iteration step length, a positive number
    output:
        losses: the loss of each step, a list of max_iters positive number
        ws: the paramater of each feature at each step, a list of max_iters d*1 vectors
        
    '''   
    w = initial_w
    ws = [w]
    losses = [compute_loss_LS(y, tx, w)]
    for i in range(max_iters):
        
        gradient = compute_gradient_LS(y, tx, w)
        
        w = w - gamma*gradient
        ws.append(w)
        
        loss = compute_loss_LS(y, tx, w)
        losses.append(loss)
    
    return losses, ws

def least_squares_SGD(y, tx, initial_w, max_iters, gamma, batch_size = 1):
    '''
    Linear regression using stochastic gradient descent
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        initial_w: the initial paramater of each feature, d*1 vector
        max_iters: the maximum iterations of this algorithm, an integer
        gamma: iteration step length, a positive number
        batch_size: batch size in mini-batch SGD, default value is 1, a positive integer less than n
    output:
        losses: the loss of each step, a list of max_iters positive number
        ws: the paramater of each feature at each step, a list of d*1 vectors
        
    '''
    w = initial_w
    ws = [w]
    losses = [compute_loss_LS(y, tx, w)]
    
    for i in range(max_iters):
        for y_batch, tx_batch in batch_iter(y, tx, batch_size=batch_size, num_batches=1):
            
            gradient = compute_gradient_LS(y_batch, tx_batch, w, loss_type = 'MSE')
            
            w = w-gamma*gradient            
            ws.append(w)
            
            loss = compute_loss_LS(y, tx, w)
            losses.append(loss)
            
        
    return losses, ws

def least_squares(y, tx):
    '''
    Least squares regression using normal equations
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
    output:
        loss: the final loss of model
        w: the final paramater of each feature, a d*1 vector
    '''
    w = np.dot(np.linalg.pinv((tx.T).dot(tx)),(tx.T).dot(y))
    loss = compute_loss_LS(y, tx, w)
    return loss, w

def ridge_regression(y, tx, lambda_):
    '''
    Ridge regression using normal equations
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        lambda_: the parameter of the regularizer, a positive number 
    output:
        loss: the final loss of model
        w: the final paramater of each feature, a d*1 vector
    '''
    tx_temp = tx.T.dot(tx) + 2*tx.shape[0]*lambda_*np.identity(tx.shape[1])
    
    w = np.dot(np.linalg.pinv(tx_temp),tx.T.dot(y))
    
    loss = compute_loss_LS(y, tx, w)
    
    return loss, w

def logistic_regression(y, tx, initial_w,max_iters, gamma):
    '''
    Logistic regression using gradient descent or SGD
    This implementation use GD
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        initial_w: the initial paramater of each feature, d*1 vector
        max_iters: the maximum iterations of this algorithm, an integer
        gamma: iteration step length, a positive number
    output:
        
        losses: the loss of each step, a list of max_iters positive number
        ws: the paramater of each feature at each step, a list of d*1 vectors
    
    '''
    y_normed = y
    y_normed[np.where(y_normed == -1)] = 0
    w = initial_w
    ws = [w]
    losses = [compute_loss_LS(y, tx, w)]
    for i in range(max_iters):
        
        gradient = compute_gradient_Logistic(y_normed,tx,w)
        
        w = w - gamma*gradient
        ws.append(w)
        
        loss = compute_loss_Logistic(y_normed, tx, w)
        losses.append(loss)
    
    return losses, ws


def reg_logistic_regression(y, tx, lambda_ ,initial_w, max_iters, gamma):
    '''
    Regularized logistic regression using gradient descent or SGD
    This implementation use GD
    input:
        y: the value of the data, n*1 matrix
        tx: the dataset with n data, d features, n*d matrix
        lambda_: the parameter of regularizer
        initial_w: the initial paramater of each feature, d*1 vector
        max_iters: the maximum iterations of this algorithm, an integer
        gamma: iteration step length, a positive number
    output:
        losses: the loss of each step, a list of max_iters positive number
        ws: the paramater of each feature at each step, a list of d*1 vectors
        
    
    '''
    y_normed = y
    y_normed[np.where(y_normed == -1)] = 0
    w = initial_w
    ws = [w]
    losses = [compute_loss_LS(y_normed, tx, w)]
    for i in range(max_iters):
        
        gradient = compute_gradient_reg_Logistic(y_normed,tx,w,lambda_)
        
        w = w - gamma*gradient
        ws.append(w)
        
        loss = compute_loss_Logistic(y_normed, tx, w)
        losses.append(loss)

    return losses, ws

