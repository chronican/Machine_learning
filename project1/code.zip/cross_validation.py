# -*- coding: utf-8 -*-
"""
cross validation algorithom
"""

import math
import numpy as np
from implementations import *
from proj1_helpers import *

def cross_validation(x, y, k, lambda_ =1, initial_w =1, max_iters=1, gamma=1,function_type = 'ridge_regression'):
    '''
    input:
        1. For randomly partition:
        x: the dataset with n data, d features, n*d matrix
        y: the value of the data, n*1 matrix
        k: the total number of groups, partition the dataset into k groups
        
        2. For ML model:
        lambda_: the parameter of regularizer
        initial_w: the initial paramater of each feature, d*1 vector
        max_iters: the maximum iterations of this algorithm, an integer
        gamma: iteration step length, a positive number
        
    output:
        loss: the final loss
        w: the final paramater, a d*1 vectors
        accuracy: the generation error
        variance: the variance of generation error
    
    '''
    # initialization
    num_total = x.shape[0]
    #print(num_total)
    num_testing = math.ceil(num_total/k)
    #print(num_testing)
    
    # randomly partition
    seed = 6
    np.random.seed(seed)
    indices = np.random.permutation(num_total)
    
    # implement method
    loss = 10000
    accuracy = 0
    variance = 0
    accuracy_record = np.zeros(k)
    for i in range(k):
        #print(i)
        
        indices_test = indices[i*num_testing:(i+1)*num_testing]
        if i==0:
            indices_train = indices[num_testing:num_total]
        elif i==k:
            indices_train = indices[0:(num_total-num_testing)]
        else:
            indices_train_tmp1 = indices[0:i*num_testing]
            indices_train_tmp2 = indices[(i+1)*num_testing:num_total]
            indices_train = np.concatenate([indices_train_tmp1,indices_train_tmp2],axis=0)
        x_train = x[indices_train]
        y_train = y[indices_train]
        x_test = x[indices_test]
        y_test = y[indices_test]
        
        #print(x_train)
        #print(y_train)
        #loss_tmp,w_tmp = reg_logistic_regression(y_train, x_train, lambda_ ,initial_w, max_iters, gamma)
        
        if function_type is 'least_squares':
            loss_tmp,w_tmp = least_squares(y_train, x_train)
        elif function_type is 'ridge_regression':
            loss_tmp,w_tmp = ridge_regression(y_train, x_train, lambda_)
        elif function_type is 'least_squares_SGD':
            losses_tmp,ws_tmp = least_squares_SGD(y_train, x_train, initial_w, max_iters, gamma, batch_size = 1)
            loss_tmp = losses_tmp[-1]
            w_tmp = ws_tmp[-1]
        elif function_type is 'logistic_regression':
            losses_tmp,ws_tmp = logistic_regression(y_train, x_train, initial_w,max_iters, gamma)
            loss_tmp = losses_tmp[-1]
            w_tmp = ws_tmp[-1]
        elif function_type is 'reg_logistic_regression':
            losses_tmp,ws_tmp = reg_logistic_regression(y_train, x_train, lambda_ ,initial_w, max_iters, gamma)
            loss_tmp = losses_tmp[-1]
            w_tmp = ws_tmp[-1]
        elif function_type is 'least_squares_GD':
            losses_tmp,ws_tmp = least_squares_GD(y_train, x_train, initial_w,max_iters, gamma)
            loss_tmp = losses_tmp[-1]
            w_tmp = ws_tmp[-1]
        else:
            print('wrong function type')
        
        
        
        
        if i==0:
            w=w_tmp
        else:
            w=w+w_tmp
        
        if loss_tmp < loss:
            loss = loss_tmp
        
            
        accuracy_tmp=1-np.sum(np.abs(y_test-predict_labels(w_tmp, x_test)))/2/len(y_test)
        #print(accuracy_tmp)
        accuracy_record[i] = accuracy_tmp
        accuracy=accuracy+accuracy_tmp
    
    w=w/k
    accuracy=accuracy/k
    for i in range(k):
        variance=variance+(accuracy_record[i]-accuracy)**2
    variance=variance/k

    return loss,w,accuracy,variance
        