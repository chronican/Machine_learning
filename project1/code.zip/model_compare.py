# -*- coding: utf-8 -*-
'''

this script compare the model with different data processing steps
'''
import sys
#sys.path.append("/data_wrangling")
from preprocessing import *
from implementations import *
#from implementations_helpers import*
from cross_validation import *
from proj1_helpers import *
import matplotlib.pyplot as plt

y_train, x_train, id_train = load_csv_data("train.csv")
#accuracies = []
'''
the origin data with ridge regression
'''

x_train0 = standardize(x_train)
tx_train0 = build_poly(x_train0, 1)

loss,w0,accuracy_origin,variance=cross_validation(tx_train0,y_train,5, lambda_ =0.00001,initial_w =1, max_iters=1, gamma=1,function_type = 'ridge_regression')
#accuracies.append(accuracy_origin)

print('without any data processing: accuracy is: '+str(accuracy_origin))


'''
Data Grouping
'''
#y_train, x_train, id_train = load_csv_data("train.csv")

jet_index_train = data_mass_index(x_train)
x_train1 = data_processing(x_train)


accuracies=np.zeros(8)
for i in range(len(jet_index_train)):

    train_index1 = jet_index_train[i]

    x_tr1 = x_train1[train_index1]
    y_tr1 = y_train[train_index1]   
    #print(x_tr1.shape[1])
    
    x_tr1_std = standardize(x_train1[train_index1])
    
    tx_tr1 = build_poly(x_tr1_std, 1)


    loss,w1,accuracies[i],variance=cross_validation(tx_tr1,y_tr1,5,lambda_ =0.00001, initial_w =1, max_iters=1, gamma=1,function_type = 'ridge_regression')
    
accuracy_1=0
total_num=0
for i in range(len(jet_index_train)):
    accuracy_1=accuracy_1+accuracies[i]*len(jet_index_train[i])
    total_num=total_num+len(jet_index_train[i])
accuracy_1=accuracy_1/total_num
print('Data Grouping, accuracy is:'+str(accuracy_1))       


'''
Data Grouping and Feature Removing
'''


jet_index_train = data_mass_index(x_train)
x_train2 = data_processing(x_train)


accuracies=np.zeros(8)
for i in range(len(jet_index_train)):

    train_index2 = jet_index_train[i]

    x_tr2 = x_train2[train_index2]
    y_tr2 = y_train[train_index2]  
    
    x_tr2 = eliminate_invalid_columns(x_tr2,i)
    
    #print(x_tr2.shape[1])
    
    x_tr2_std = standardize(x_tr2)
    
    tx_tr2 = build_poly(x_tr2_std, 1)


    loss,w2,accuracies[i],variance=cross_validation(tx_tr2,y_tr2,5,lambda_ =0.00001, initial_w =0.00001, max_iters=1, gamma=1,function_type = 'ridge_regression')
    
accuracy_2=0
total_num=0
for i in range(len(jet_index_train)):
    accuracy_2=accuracy_2+accuracies[i]*len(jet_index_train[i])
    total_num=total_num+len(jet_index_train[i])
accuracy_2=accuracy_2/total_num
print('Data Grouping and Feature Removing, accuracy is:'+str(accuracy_2)) 