# -*- coding: utf-8 -*-
"""
This file define some functions used in parameter choosing 
"""
from implementations import *
from proj1_helpers import *

def split_dataset(y,tx,ratio = 0.2):
    '''
    split the origin data set into 2 sets randomly - a training set and a testing set
    input:
        y: original objective value
        tx: original data
        ratio: ratio of data to be tested
    output:
        y_test
        tx_test
        y_train
        tx_train
    '''
    num_data = len(y)
    num_test = round(ratio*num_data)
    num_train = num_data - num_test
    test_indices = np.random.permutation(np.arange(num_test))
    
    y_test = y[test_indices]
    tx_test = tx[test_indices,:]
    y_train = np.delete(y,test_indices,axis = 0)
    tx_train = np.delete(tx,test_indices,axis = 0)
    if len(y_train) + len(y_test) != num_data:
        print('wrong spliit')
    
    return y_test,tx_test,y_train,tx_train


def compute_acurracy(y,tx,w):
    '''
    test the acurrancy of model w
    input:
        y: original objective value
        tx: original data 
        w: predicted model
    output:
        acurracy: (correct predicts)/(total predicts)   
    '''
    acurracy = 0
    y_pred = predict_labels(w, tx)
    correct_num = len(np.where(y == y_pred)[0])
    acurracy = correct_num/len(y)
    
    return acurracy


def get_acurracy_by_gamma(y_test, tx_test, y_train, tx_train, 
                 lambda_ ,initial_w, max_iters, gamma_range, function_type):
    '''
    get the acurracies with different gamma(learning rate) and fixed all other parameter for 
    least_squares_GD(y, tx, initial_w,max_iters, gamma),
    least_squares_SGD(y, tx, initial_w, max_iters, gamma, batch_size = 1),
    logistic_regression(y, tx, initial_w,max_iters, gamma),
    reg_logistic_regression(y, tx, lambda_ ,initial_w, max_iters, gamma)
    '''
    acurracies = []
    
    if function_type is 'least_squares_GD':
        for gamma in gamma_range:
            losses, ws = least_squares_GD(y_train, tx_train, initial_w,max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
            
        
    elif function_type is 'least_squares_SGD':
        for gamma in gamma_range:
            losses, ws = least_squares_SGD(y_train, tx_train, initial_w, max_iters, gamma, batch_size = 1)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
        
    elif function_type is 'logistic_regression':
        for gamma in gamma_range:
            losses, ws = logistic_regression(y_train, tx_train, initial_w,max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
        
    elif function_type is 'reg_logistic_regression':
        for gamma in gamma_range:
            losses, ws = reg_logistic_regression(y_train, tx_train, lambda_ ,initial_w, max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
    
    else:
        print('wrong function type')
        
    return acurracies
        
        
def get_acurracy_by_iters(y_test, tx_test, y_train, tx_train, 
                 lambda_ ,initial_w, max_iters_range, gamma, function_type): 
    '''
    get the acurracies with different iteration numbers and fixed all other parameter for 
    least_squares_GD(y, tx, initial_w,max_iters, gamma),
    least_squares_SGD(y, tx, initial_w, max_iters, gamma, batch_size = 1),
    logistic_regression(y, tx, initial_w,max_iters, gamma),
    reg_logistic_regression(y, tx, lambda_ ,initial_w, max_iters, gamma)
    '''
    acurracies = []
    if function_type is 'least_squares_GD':
        for max_iters in max_iters_range:
            losses, ws = least_squares_GD(y_train, tx_train, initial_w,max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
            
        
    elif function_type is 'least_squares_SGD':
        for max_iters in max_iters_range:
            losses, ws = least_squares_SGD(y_train, tx_train, initial_w, max_iters, gamma, batch_size = 1)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
        
    elif function_type is 'logistic_regression':
        for max_iters in max_iters_range:
            losses, ws = logistic_regression(y_train, tx_train, initial_w,max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
        
    elif function_type is 'reg_logistic_regression':
        for max_iters in max_iters_range:
            losses, ws = reg_logistic_regression(y_train, tx_train, lambda_ ,initial_w, max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
    
    else:
        print('wrong function type')
        
    return acurracies


def get_acurracy_by_lambda(y_test, tx_test, y_train, tx_train, 
                 lambda_range ,initial_w, max_iters_range, gamma, function_type): 
    '''
    get the acurracies with different lambda_(pennalty) and fixed all other parameter for: 
    ridge_regression(y, tx, lambda_)
    reg_logistic_regression(y, tx, lambda_ ,initial_w, max_iters, gamma)
    '''
    acurracy = 0
    if function_type is 'ridge_regression':
        for lambda_ in max_iters_range:
            loss, w = ridge_regression(y, tx, lambda_)
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
        

        
    elif function_type is 'reg_logistic_regression':
        for lambda_ in max_iters_range:
            losses, ws = reg_logistic_regression(y_train, tx_train, lambda_ ,initial_w, max_iters, gamma)
            w = ws[-1]
            acurracy = compute_acurracy(y_test,tx_test,w)
            acurracies.append(acurracy)
    
    else:
        print('wrong function type')
        
    return acurracies  

def get_acurracy(y_test, tx_test, y_train, tx_train, 
                 lambda_ ,initial_w, max_iters, gamma, function_type): 
    '''
    get the acurracies with different iteration numbers and fixed all other parameter for 
    least_squares_GD(y, tx, initial_w,max_iters, gamma),
    least_squares_SGD(y, tx, initial_w, max_iters, gamma, batch_size = 1),
    logistic_regression(y, tx, initial_w,max_iters, gamma),
    reg_logistic_regression(y, tx, lambda_ ,initial_w, max_iters, gamma)
    '''
    acurracy = 0
    if function_type is 'least_squares_GD':
        
        losses, ws = least_squares_GD(y_train, tx_train, initial_w,max_iters, gamma)
        w = ws[-1]
        acurracy = compute_acurracy(y_test,tx_test,w)
        
            
        
    elif function_type is 'least_squares_SGD':
    
        losses, ws = least_squares_SGD(y_train, tx_train, initial_w, max_iters, gamma, batch_size = 1)
        w = ws[-1]
        acurracy = compute_acurracy(y_test,tx_test,w)
        
    
    elif function_type is 'least_squares':
        
        loss, w = least_squares(y_train, tx_train)
        acurracy = compute_acurracy(y_test,tx_test,w)
        
        
    elif function_type is 'ridge_regression':
        
        loss,w = ridge_regression(y_train, tx_train, lambda_)
        acurracy = compute_acurracy(y_test,tx_test,w)
        
        
    elif function_type is 'logistic_regression':
        
        losses, ws = logistic_regression(y_train, tx_train, initial_w,max_iters, gamma)
        w = ws[-1]
        acurracy = compute_acurracy(y_test,tx_test,w)
        
        
    elif function_type is 'reg_logistic_regression':
        
        losses, ws = reg_logistic_regression(y_train, tx_train, lambda_ ,initial_w, max_iters, gamma)
        w = ws[-1]
        acurracy = compute_acurracy(y_test,tx_test,w)
        
    
    
    
    else:
        print('wrong function type')
        
    return acurracy